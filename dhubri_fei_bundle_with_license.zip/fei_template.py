# FEI Calculation Template

# Inputs: 
# - dhubri_blocks.geojson
# - travel_times.csv
# - flood_days.csv

# This script combines open-access travel time and flood extent data
# to compute a simple Flood Exposure Index per block.

import pandas as pd

flood = pd.read_csv("flood_days.csv")
travel = pd.read_csv("travel_times.csv")

merged = pd.merge(flood, travel, on="block_name")
merged["travel_time_ratio"] = merged["travel_time_flood"] / merged["travel_time_dry"]

# FEI formula (weights: 0.4, 0.3, 0.3)
merged["FEI"] = (
    0.4 * (merged["days_submerged"] / 30) +
    0.3 * merged["travel_time_ratio"] +
    0.3 * 0.5  # placeholder for Pop_Flood_Zone ratio
)

merged.to_csv("dhubri_fei_output.csv", index=False)
