# Dhubri FEI Dataset (Simulated Package)

This repository contains **simulated files** for illustrating how to calculate the Flood Exposure Index (FEI) for Dhubri district, Assam, using **open-access data only**. These files serve as placeholders and templates to ensure reproducibility. 

## ⚠️ Important Note
The files provided here are **not real geospatial data or measured field inputs**. They are meant to simulate the structure and logic of the FEI methodology for Dhubri using publicly available datasets. You must replace the dummy data with actual inputs as outlined below.


### 📌 Open Data Sources for Population and Facility Reference

- **Census 2011 Village Amenities (includes PHC/CHC/SC availability)**  
  [https://censusindia.gov.in/nada/index.php/catalog/10291](https://censusindia.gov.in/nada/index.php/catalog/10291)

- **Census Village Directory (Assam)**  
  [https://censusindia.gov.in/census.website/data/village-directory](https://censusindia.gov.in/census.website/data/village-directory)

- **Census GIS Villages Shapefile (Wards and Villages with Centroids)**  
  [https://gis.censusindia.gov.in/](https://gis.censusindia.gov.in/)

- **State Report on PHC/CHC Availability (NHM Assam)**  
  [https://nhm.assam.gov.in/portlets/infrastructure](https://nhm.assam.gov.in/portlets/infrastructure)


---

## ✅ Actual Procedure (Fully Reproducible Workflow)

### 1. Download Real Block Boundaries
- Visit: https://data.humdata.org/dataset/geoboundaries-admin-boundaries-for-india
- Download the `geoBoundaries-IND-ADM3.geojson` file
- Open it in a GIS tool or Python, and filter rows where `shapeName` contains "Dhubri", "Mankachar", "Salmara", etc. (use district reference)

### 2. Obtain Population and Facility Reference
- Census 2011 village amenities data: https://censusindia.gov.in/census.website/data/census-tables
- Use PHC/CHC availability fields to approximate facility locations

### 3. Compute Flood Submersion Days
- Use Sentinel-1 SAR imagery from 2018–2023
- Classify flooded pixels (e.g., VV backscatter < –16 dB)
- Aggregate monthly frequency of flood presence
- Zonal stats per block = Days Submerged

### 4. Estimate Travel Time
- Use OpenRouteService API: https://openrouteservice.org
- Inputs:
  - Origins: village centroids from Census shapefiles
  - Destinations: block HQ or PHC proxy village
- Run routing twice:
  - Once with full road network (dry season)
  - Once with roads removed where flood overlay intersects

### 5. Calculate Flood Exposure Index (FEI)
\[
FEI = 0.4 × (Days_Submerged / 30) + 0.3 × (Travel_Time_Flood / Travel_Time_Dry) + 0.3 × (Pop_Flood_Zone / Total_Pop)
\]

---

## 📁 Folder Contents

| File | Description |
|------|-------------|
| `dhubri_blocks.geojson` | Simulated block boundary file (replace with filtered ADM3 data) |
| `travel_times.csv` | Placeholder table of travel times (dry/flooded) per block |
| `flood_days.csv` | Placeholder table of average days submerged per block |
| `fei_template.py` | Sample Python script for merging inputs and calculating FEI |
| `README.md` | This documentation file |

---

## 📘 Citations

- GeoBoundaries India ADM3: [https://geoboundaries.org](https://geoboundaries.org)
- Sentinel-1 SAR (via Copernicus): [https://scihub.copernicus.eu](https://scihub.copernicus.eu)
- OpenRouteService (ORS): [https://openrouteservice.org](https://openrouteservice.org)
- Census of India: [https://censusindia.gov.in](https://censusindia.gov.in)
- HMIS Dashboard: [https://hmis.mohfw.gov.in](https://hmis.mohfw.gov.in)



---

## 🧩 Optional Extensions for Full FEI and Validation

### 🔹 6. Pop_Flood_Zone / Total_Pop Ratio

This is the third and final component of the Flood Exposure Index (FEI):

\[
	ext{Population Exposure} = rac{	ext{Population in Flood Zone}}{	ext{Total Block Population}}
\]

**Steps to compute:**
1. Download the 2011 Census Village Directory (with population) and GIS shapefile:
   - [https://censusindia.gov.in/census.website/data/village-directory](https://censusindia.gov.in/census.website/data/village-directory)
   - [https://gis.censusindia.gov.in/](https://gis.censusindia.gov.in/)
2. Process Sentinel-1 imagery into a flood extent raster (e.g., using VV backscatter < –16 dB).
3. For each village:
   - Overlay village centroid or polygon on the flood raster
   - Flag as “flood-affected” if intersected by flood pixels
4. For each block:
   - Sum population of flood-affected villages
   - Divide by total population of that block

Save output as: `pop_flood_zone.csv` with fields:
- block_name
- pop_flood_zone
- total_pop
- pop_ratio

Update the FEI formula with this third term:
\[
FEI = 0.4 × \left(rac{	ext{Days Submerged}}{30}ight) + 0.3 × \left(rac{	ext{Travel Time Flood}}{	ext{Travel Time Dry}}ight) + 0.3 × \left(rac{	ext{Pop Flood Zone}}{	ext{Total Pop}}ight)
\]

---

### 🔹 7. Optional Regression Analysis (for Validation)

Once FEI values are computed per block, you can examine their association with public health outcomes using regression models.

**Suggested outcomes:**
- % fully immunized children (NFHS-5, district only)
- Institutional deliveries per block (HMIS, facility-level reports)

**Data Sources:**
- NFHS-5 District Factsheet: [http://rchiips.org/nfhs](http://rchiips.org/nfhs)
- HMIS Dashboard: [https://hmis.mohfw.gov.in](https://hmis.mohfw.gov.in)

**Steps:**
1. Download HMIS Excel files (district-level, disaggregated by facility).
2. Assign facilities to blocks (by name) using lookup or administrative table.
3. Aggregate to get block-level indicators such as:
   - % ANC-4 completed
   - % institutional deliveries
4. Run regression in Python or R:

```python
import statsmodels.formula.api as smf
df = pd.read_csv("fei_and_health.csv")
model = smf.ols("immunization_coverage ~ FEI", data=df).fit()
print(model.summary())
```

This can help validate whether flood exposure is statistically associated with weaker health system performance.

---


---

## 📚 Citation

If you use or adapt this repository, please cite it as:

**Varna Sri Raman** (2025). *Dhubri Flood Exposure Index: Reproducible Spatial Analysis Using Open Data*. GitHub. https://github.com/yourusername/dhubri-fei
